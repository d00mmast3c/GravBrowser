(function () {
  if (window.__gravHook) return;
  window.__gravHook = true;
  var h = location.hostname;
  if (!/(chromewebstore\.google\.com|chrome\.google\.com|addons\.mozilla\.org)$/.test(h)) return;

  document.addEventListener('click', function (ev) {
    var el = ev.target && ev.target.closest ? ev.target.closest('a,button,[role="button"]') : null;
    if (!el || !window.GravBridge) return;
    var t = (el.innerText || el.textContent || '').trim().toLowerCase().replace(/\s+/g, ' ');
    var hit = /^(adicionar ao |add to |instalar|install)/.test(t) && t.length < 40;
    if (!hit) return;

    ev.preventDefault();
    ev.stopPropagation();
    ev.stopImmediatePropagation();

    var h1 = document.querySelector('h1');
    var name = ((h1 && h1.textContent) || document.title || '').split(' - ')[0].split(' \u2013 ')[0].trim();
    window.GravBridge.onInstallRequest(location.href, name);
  }, true);
})();
