package com.grav.browser;

import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";

    private FrameLayout container;
    private EditText urlBar;
    private ImageView favicon;
    private ImageButton btnBack, btnForward, btnReload, btnMenu;
    private Button btnTabs;
    private View bottomBar;
    private PullRefreshLayout pull;
    private LinearProgressIndicator progressBar;

    private final List<BrowserTab> tabs = new ArrayList<>();
    private BrowserTab current;
    private ExtensionManager ext;
    private HistoryManager history;
    private String storeHook = "";
    private String defaultUa = "";

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);

        View rootView = findViewById(R.id.root);
        ViewCompat.setOnApplyWindowInsetsListener(rootView, (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            Insets ime = insets.getInsets(WindowInsetsCompat.Type.ime());
            v.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, ime.bottom));
            return WindowInsetsCompat.CONSUMED;
        });

        container = findViewById(R.id.container);
        urlBar = findViewById(R.id.urlBar);
        favicon = findViewById(R.id.favicon);
        btnBack = findViewById(R.id.btnBack);
        btnForward = findViewById(R.id.btnForward);
        btnReload = findViewById(R.id.btnReload);
        btnTabs = findViewById(R.id.btnTabs);
        btnMenu = findViewById(R.id.btnMenu);
        bottomBar = findViewById(R.id.bottomBar);
        progressBar = findViewById(R.id.progressBar);
        pull = findViewById(R.id.pullRefresh);
        pull.setListener(new PullRefreshLayout.Listener() {
            @Override
            public boolean canScrollUp() {
                return current != null && current.web.canScrollVertically(-1);
            }

            @Override
            public void onRefresh() {
                if (current != null) current.web.reload();
            }
        });

        ext = new ExtensionManager(this);
        history = new HistoryManager(this);
        try {
            storeHook = readAsset("store_hook.js");
        } catch (IOException e) {
            storeHook = "";
        }
        defaultUa = new WebView(this).getSettings().getUserAgentString();

        btnBack.setOnClickListener(v -> {
            if (current != null && current.web.canGoBack()) current.web.goBack();
        });
        btnForward.setOnClickListener(v -> {
            if (current != null && current.web.canGoForward()) current.web.goForward();
        });
        btnReload.setOnClickListener(v -> current.web.reload());
        btnTabs.setOnClickListener(v -> showTabsSheet());
        btnMenu.setOnClickListener(v -> showMenu());
        urlBar.setOnEditorActionListener((v, actionId, ev) -> {
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                load(urlBar.getText().toString());
                return true;
            }
            return false;
        });

        int saved = state == null ? 0 : state.getInt("tabCount", 0);
        String[] urls = state == null ? null : state.getStringArray("tabUrls");
        boolean[] incs = state == null ? null : state.getBooleanArray("tabInc");
        if (saved > 0 && urls != null && incs != null && urls.length == saved && incs.length == saved) {
            int cur = Math.max(0, Math.min(saved - 1, state.getInt("tabCur", 0)));
            for (int i = 0; i < saved; i++) {
                String u = (urls[i] == null || urls[i].isEmpty()) ? home() : urls[i];
                createTab(u, incs[i], i == cur);
            }
        } else {
            createTab(home(), false, true);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        int n = tabs.size();
        String[] urls = new String[n];
        boolean[] incs = new boolean[n];
        int cur = 0;
        for (int i = 0; i < n; i++) {
            BrowserTab t = tabs.get(i);
            String u = t.web.getUrl();
            urls[i] = u == null ? t.url : u;
            incs[i] = t.incognito;
            if (t == current) cur = i;
        }
        out.putInt("tabCount", n);
        out.putStringArray("tabUrls", urls);
        out.putBooleanArray("tabInc", incs);
        out.putInt("tabCur", cur);
    }

    @Override
    protected void onResume() {
        super.onResume();
        for (BrowserTab t : tabs) applySettings(t);
    }

    @Override
    public void onBackPressed() {
        if (current != null && current.web.canGoBack()) current.web.goBack();
        else super.onBackPressed();
    }

    private String home() {
        return "https://www.google.com";
    }

    // ---------- Guias ----------

    private BrowserTab createTab(String url, boolean incognito, boolean select) {
        WebView w = new WebView(this);
        w.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        BrowserTab t = new BrowserTab(w, incognito);
        t.desktop = Prefs.desktopDefault(this);
        applySettings(t);

        w.setWebViewClient(new Client(t));
        w.setWebChromeClient(new Chrome(t));
        w.setDownloadListener(downloadListener());
        if (!incognito) w.addJavascriptInterface(new StoreBridge(), "GravBridge");

        tabs.add(t);
        container.addView(w);
        if (select) showTab(t);
        else w.setVisibility(View.GONE);

        if (url != null) w.loadUrl(url);
        return t;
    }

    private void showTab(BrowserTab t) {
        current = t;
        for (BrowserTab x : tabs) x.web.setVisibility(x == t ? View.VISIBLE : View.GONE);
        pull.stopRefreshing();
        updateChrome();
    }

    private void closeTab(BrowserTab t) {
        container.removeView(t.web);
        if (t.incognito) t.web.clearCache(true);
        t.web.stopLoading();
        t.web.destroy();
        tabs.remove(t);
        if (tabs.isEmpty()) {
            createTab(home(), false, true);
        } else if (current == t) {
            showTab(tabs.get(tabs.size() - 1));
        } else {
            updateChrome();
        }
    }

    private void applySettings(BrowserTab t) {
        WebSettings s = t.web.getSettings();
        s.setJavaScriptEnabled(Prefs.js(this));
        s.setLoadsImagesAutomatically(Prefs.images(this));
        s.setDomStorageEnabled(!t.incognito);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setAllowFileAccess(false);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(!t.desktop);
        s.setUserAgentString(t.desktop ? DESKTOP_UA : defaultUa);
        if (t.incognito) s.setCacheMode(WebSettings.LOAD_NO_CACHE);
    }

    private void updateChrome() {
        if (current == null) return;
        if (!urlBar.hasFocus()) urlBar.setText(current.url);
        if (current.favicon != null) favicon.setImageBitmap(current.favicon);
        else favicon.setImageResource(R.drawable.ic_globe);
        btnTabs.setText(String.valueOf(tabs.size()));
        btnBack.setEnabled(current.web.canGoBack());
        btnForward.setEnabled(current.web.canGoForward());
        updateProgress();
    }

    private void updateProgress() {
        if (current == null) return;
        int p = current.progress;
        if (p >= 100 || p <= 0) {
            progressBar.setVisibility(View.INVISIBLE);
        } else {
            progressBar.setVisibility(View.VISIBLE);
            progressBar.setProgressCompat(p, true);
        }
    }

    // ---------- Navegação ----------

    private void load(String input) {
        String s = input == null ? "" : input.trim();
        if (s.isEmpty()) return;
        String url;
        if (s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) {
            url = s;
        } else if (!s.contains(" ") && s.contains(".")) {
            url = "https://" + s;
        } else {
            try {
                url = Prefs.searchUrl(this) + URLEncoder.encode(s, "UTF-8");
            } catch (Exception e) {
                return;
            }
        }
        current.web.loadUrl(url);
    }

    private class Client extends WebViewClient {
        private final BrowserTab t;

        Client(BrowserTab t) {
            this.t = t;
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            String sc = u.getScheme();
            if ("http".equals(sc) || "https".equals(sc) || "about".equals(sc)
                    || "data".equals(sc) || "blob".equals(sc)) {
                return false;
            }
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, u));
            } catch (ActivityNotFoundException e) {
                toast(getString(R.string.no_app_for_link));
            }
            return true;
        }

        @Override
        public void onPageStarted(WebView v, String url, Bitmap icon) {
            t.url = url;
            if (t == current) updateChrome();
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            t.url = url;
            t.title = v.getTitle() == null ? url : v.getTitle();
            if (!t.incognito) {
                history.add(url, t.title, t.favicon);
                if (ExtensionManager.isStoreHost(url) && !storeHook.isEmpty()) {
                    v.evaluateJavascript(storeHook, null);
                }
                String inj = ext.buildInjection(url);
                if (!inj.isEmpty()) v.evaluateJavascript(inj, null);
            }
            if (t == current) {
                pull.stopRefreshing();
                updateChrome();
            }
        }
    }

    private class Chrome extends WebChromeClient {
        private final BrowserTab t;

        Chrome(BrowserTab t) {
            this.t = t;
        }

        @Override
        public void onReceivedIcon(WebView v, Bitmap icon) {
            t.favicon = icon;
            if (t == current) updateChrome();
        }

        @Override
        public void onReceivedTitle(WebView v, String title) {
            t.title = title;
        }

        @Override
        public void onProgressChanged(WebView v, int p) {
            t.progress = p;
            if (t == current) {
                updateProgress();
                if (p >= 100) pull.stopRefreshing();
            }
        }

        @Override
        public boolean onJsAlert(WebView v, String url, String message, JsResult result) {
            Dialogs.builder(MainActivity.this)
                    .setTitle(hostOf(url))
                    .setMessage(message)
                    .setPositiveButton(R.string.btn_ok, (d, w) -> result.confirm())
                    .setOnCancelListener(d -> result.cancel())
                    .show();
            return true;
        }

        @Override
        public boolean onJsConfirm(WebView v, String url, String message, JsResult result) {
            Dialogs.builder(MainActivity.this)
                    .setTitle(hostOf(url))
                    .setMessage(message)
                    .setPositiveButton(R.string.btn_ok, (d, w) -> result.confirm())
                    .setNegativeButton(R.string.btn_cancel, (d, w) -> result.cancel())
                    .setOnCancelListener(d -> result.cancel())
                    .show();
            return true;
        }

        @Override
        public boolean onJsPrompt(WebView v, String url, String message, String def, JsPromptResult result) {
            final EditText input = new EditText(MainActivity.this);
            input.setText(def == null ? "" : def);
            Dialogs.builder(MainActivity.this)
                    .setTitle(hostOf(url))
                    .setMessage(message)
                    .setView(input)
                    .setPositiveButton(R.string.btn_ok, (d, w) -> result.confirm(input.getText().toString()))
                    .setNegativeButton(R.string.btn_cancel, (d, w) -> result.cancel())
                    .setOnCancelListener(d -> result.cancel())
                    .show();
            return true;
        }
    }

    private DownloadListener downloadListener() {
        return (url, ua, cd, mime, len) -> {
            try {
                String name = URLUtil.guessFileName(url, cd, mime);
                DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                r.setMimeType(mime);
                r.addRequestHeader("User-Agent", ua);
                r.setTitle(name);
                r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                r.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, name);
                ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
                toast(getString(R.string.downloading, name));
            } catch (Exception e) {
                toast(getString(R.string.download_failed));
            }
        };
    }

    // ---------- Menu popup (estilo Chrome) ----------

    private void showMenu() {
        View v = getLayoutInflater().inflate(R.layout.popup_menu, null);
        final PopupWindow pw = new PopupWindow(v, dp(260), ViewGroup.LayoutParams.WRAP_CONTENT, true);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(attrColor(com.google.android.material.R.attr.colorSurface));
        bg.setCornerRadius(dp(16));
        pw.setBackgroundDrawable(bg);
        pw.setElevation(dp(8));
        pw.setAnimationStyle(R.style.PopupMenuAnim);
        pw.setOutsideTouchable(true);

        CheckBox cd = v.findViewById(R.id.checkDesktop);
        cd.setChecked(current != null && current.desktop);

        v.findViewById(R.id.itemNewTab).setOnClickListener(x -> {
            pw.dismiss();
            createTab(home(), false, true);
        });
        v.findViewById(R.id.itemNewIncognito).setOnClickListener(x -> {
            pw.dismiss();
            createTab(home(), true, true);
        });
        v.findViewById(R.id.itemHistory).setOnClickListener(x -> {
            pw.dismiss();
            showHistorySheet();
        });
        v.findViewById(R.id.itemExtensions).setOnClickListener(x -> {
            pw.dismiss();
            showExtensions();
        });
        v.findViewById(R.id.itemReload).setOnClickListener(x -> {
            pw.dismiss();
            current.web.reload();
        });
        v.findViewById(R.id.itemDesktop).setOnClickListener(x -> {
            pw.dismiss();
            current.desktop = !current.desktop;
            applySettings(current);
            current.web.reload();
        });
        v.findViewById(R.id.itemSettings).setOnClickListener(x -> {
            pw.dismiss();
            startActivity(new Intent(this, SettingsActivity.class));
        });

        int[] loc = new int[2];
        bottomBar.getLocationOnScreen(loc);
        int fromBottom = getResources().getDisplayMetrics().heightPixels - loc[1] + dp(8);
        pw.showAtLocation(bottomBar, Gravity.BOTTOM | Gravity.END, dp(8), fromBottom);
    }

    // ---------- Bottom sheets ----------

    private void setupSheet(final BottomSheetDialog dlg, View v) {
        final int h = (int) (getResources().getDisplayMetrics().heightPixels * 0.62f);
        v.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h));
        final int pb = v.getPaddingBottom();
        ViewCompat.setOnApplyWindowInsetsListener(v, (view, insets) -> {
            Insets nb = insets.getInsets(WindowInsetsCompat.Type.navigationBars());
            view.setPadding(view.getPaddingLeft(), view.getPaddingTop(), view.getPaddingRight(), pb + nb.bottom);
            return insets;
        });
        dlg.setContentView(v);
        final BottomSheetBehavior<android.widget.FrameLayout> b = dlg.getBehavior();
        b.setSkipCollapsed(true);
        b.setPeekHeight(h);
        b.setState(BottomSheetBehavior.STATE_EXPANDED);
        dlg.setOnShowListener(d -> b.setState(BottomSheetBehavior.STATE_EXPANDED));
    }

    private void showTabsSheet() {
        final BottomSheetDialog dlg = new BottomSheetDialog(this);
        View v = getLayoutInflater().inflate(R.layout.sheet_list, null);
        setupSheet(dlg, v);
        ((TextView) v.findViewById(R.id.sheetTitle)).setText(R.string.tabs_title);

        RecyclerView rv = v.findViewById(R.id.sheetList);
        rv.setLayoutManager(new LinearLayoutManager(this));
        final RowAdapter ad = new RowAdapter();
        rv.setAdapter(ad);
        refreshTabRows(ad, dlg);

        Button a = v.findViewById(R.id.sheetBtnA);
        a.setText(R.string.sheet_new_tab);
        a.setOnClickListener(x -> {
            dlg.dismiss();
            createTab(home(), false, true);
        });
        Button b = v.findViewById(R.id.sheetBtnB);
        b.setText(R.string.sheet_new_incognito);
        b.setOnClickListener(x -> {
            dlg.dismiss();
            createTab(home(), true, true);
        });
        dlg.show();
    }

    private void refreshTabRows(RowAdapter ad, BottomSheetDialog dlg) {
        List<RowAdapter.Row> rows = new ArrayList<>();
        for (BrowserTab t : tabs) {
            String base = t.title.isEmpty() ? t.url : t.title;
            String title = t.incognito ? getString(R.string.incognito_tab) + " · " + base : base;
            rows.add(new RowAdapter.Row(t.favicon, title, t.url,
                    () -> {
                        showTab(t);
                        dlg.dismiss();
                    },
                    () -> {
                        closeTab(t);
                        refreshTabRows(ad, dlg);
                    }));
        }
        ad.setRows(rows);
    }

    private void showHistorySheet() {
        final BottomSheetDialog dlg = new BottomSheetDialog(this);
        View v = getLayoutInflater().inflate(R.layout.sheet_list, null);
        setupSheet(dlg, v);
        ((TextView) v.findViewById(R.id.sheetTitle)).setText(R.string.history_title);

        RecyclerView rv = v.findViewById(R.id.sheetList);
        rv.setLayoutManager(new LinearLayoutManager(this));
        final RowAdapter ad = new RowAdapter();
        rv.setAdapter(ad);
        refreshHistoryRows(ad, dlg);

        Button a = v.findViewById(R.id.sheetBtnA);
        a.setVisibility(View.GONE);
        Button b = v.findViewById(R.id.sheetBtnB);
        b.setText(R.string.sheet_clear_history);
        b.setOnClickListener(x -> {
            history.clear();
            refreshHistoryRows(ad, dlg);
        });
        dlg.show();
    }

    private void refreshHistoryRows(RowAdapter ad, BottomSheetDialog dlg) {
        List<RowAdapter.Row> rows = new ArrayList<>();
        for (HistoryManager.Entry e : history.list()) {
            rows.add(new RowAdapter.Row(e.bitmap(), e.title, e.url,
                    () -> {
                        load(e.url);
                        dlg.dismiss();
                    },
                    () -> {
                        history.remove(e);
                        refreshHistoryRows(ad, dlg);
                    }));
        }
        ad.setRows(rows);
    }

    // ---------- Extensões ----------

    private void showExtensions() {
        final List<ExtensionManager.Ext> list = ext.all();
        if (list.isEmpty()) {
            Dialogs.builder(this)
                    .setTitle(R.string.ext_title)
                    .setMessage(R.string.ext_empty)
                    .setPositiveButton(R.string.btn_ok, null)
                    .show();
            return;
        }
        String[] names = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            ExtensionManager.Ext x = list.get(i);
            names[i] = x.name + (x.enabled ? "" : getString(R.string.ext_disabled_suffix));
        }
        Dialogs.builder(this)
                .setTitle(R.string.ext_title)
                .setItems(names, (d, which) -> {
                    final ExtensionManager.Ext sel = list.get(which);
                    Dialogs.builder(this)
                            .setTitle(sel.name)
                            .setItems(new String[]{
                                    getString(sel.enabled ? R.string.ext_disable : R.string.ext_enable),
                                    getString(R.string.ext_remove)
                            }, (d2, w2) -> {
                                if (w2 == 0) ext.setEnabled(sel, !sel.enabled);
                                else ext.remove(sel);
                                if (current != null) current.web.reload();
                            })
                            .show();
                })
                .setPositiveButton(R.string.btn_close, null)
                .show();
    }

    // ---------- Instalação via loja ----------

    private class StoreBridge {
        @JavascriptInterface
        public void onInstallRequest(final String pageUrl, final String name) {
            runOnUiThread(() -> askInstall(pageUrl, name));
        }
    }

    private void askInstall(String pageUrl, String rawName) {
        String cur = current == null ? null : current.web.getUrl();
        if (cur == null || !ExtensionManager.isStoreHost(cur)) return;

        final ExtensionManager.StoreInfo info = ExtensionManager.parseStore(pageUrl);
        if (info == null) {
            toast(getString(R.string.store_unknown));
            return;
        }
        String n = rawName == null ? "" : rawName.trim();
        final String name = n.isEmpty() ? info.id : n;

        Dialogs.builder(this)
                .setTitle(R.string.install_title)
                .setMessage(getString(R.string.install_message, name))
                .setPositiveButton(R.string.btn_yes, (d, w) -> {
                    toast(getString(R.string.installing, name));
                    ext.install(info, name, (installed, err) -> runOnUiThread(() -> {
                        if (installed != null) {
                            toast(getString(R.string.installed, installed.name));
                            if (current != null) current.web.reload();
                        } else {
                            toast(getString(R.string.install_error, err));
                        }
                    }));
                })
                .setNegativeButton(R.string.btn_no, null)
                .show();
    }

    // ---------- Utilidades ----------

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
    }

    private String hostOf(String url) {
        String h = Uri.parse(url == null ? "" : url).getHost();
        return h == null ? getString(R.string.page_title_default) : h;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private int attrColor(int attr) {
        TypedValue tv = new TypedValue();
        getTheme().resolveAttribute(attr, tv, true);
        return tv.data;
    }

    private String readAsset(String name) throws IOException {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) != -1) bo.write(buf, 0, n);
            return bo.toString("UTF-8");
        }
    }
}
