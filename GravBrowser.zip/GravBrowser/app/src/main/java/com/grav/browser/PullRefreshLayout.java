package com.grav.browser;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;

/** Puxar para baixo para recarregar, com o círculo de progresso na cor do tema. */
public class PullRefreshLayout extends FrameLayout {

    public interface Listener {
        boolean canScrollUp();
        void onRefresh();
    }

    private final SpinnerView spinner;
    private final int size;
    private final int trigger;
    private final int maxPull;
    private final int touchSlop;
    private Listener listener;
    private float startX;
    private float startY;
    private float pull;
    private boolean pulling;
    private boolean refreshing;
    private final Runnable timeout = new Runnable() {
        @Override
        public void run() {
            stopRefreshing();
        }
    };

    public PullRefreshLayout(Context c) {
        this(c, null);
    }

    public PullRefreshLayout(Context c, AttributeSet a) {
        super(c, a);
        float d = getResources().getDisplayMetrics().density;
        size = (int) (44 * d);
        trigger = (int) (64 * d);
        maxPull = (int) (130 * d);
        touchSlop = ViewConfiguration.get(c).getScaledTouchSlop();
        spinner = new SpinnerView(c, d);
        spinner.setVisibility(INVISIBLE);
        spinner.setTranslationY(-size);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        addView(spinner, new LayoutParams(size, size, Gravity.TOP | Gravity.CENTER_HORIZONTAL));
    }

    public void setListener(Listener l) {
        listener = l;
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        if (listener == null || refreshing) return false;
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                startX = ev.getX();
                startY = ev.getY();
                pulling = false;
                break;
            case MotionEvent.ACTION_MOVE:
                if (ev.getPointerCount() > 1) return false;
                float dy = ev.getY() - startY;
                float dx = Math.abs(ev.getX() - startX);
                if (!pulling && dy > touchSlop && dy > dx && !listener.canScrollUp()) {
                    pulling = true;
                    startY = ev.getY();
                    pull = 0;
                    return true;
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                pulling = false;
                break;
            default:
                break;
        }
        return pulling;
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        if (!pulling) return false;
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_MOVE:
                float dy = Math.max(0, ev.getY() - startY);
                pull = Math.min(maxPull, dy * 0.6f);
                showPull(pull);
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                pulling = false;
                if (ev.getActionMasked() == MotionEvent.ACTION_UP && pull >= trigger) startRefresh();
                else hide();
                return true;
            default:
                return true;
        }
    }

    private void showPull(float p) {
        spinner.animate().cancel();
        spinner.setAlpha(1f);
        spinner.setVisibility(VISIBLE);
        spinner.setTranslationY(p - size);
        spinner.setProgress(Math.min(1f, p / trigger));
        spinner.setPullRotation(p * 2.5f);
    }

    private void startRefresh() {
        refreshing = true;
        spinner.animate().cancel();
        spinner.animate().translationY(trigger - size).setDuration(150).start();
        spinner.setSpinning(true);
        removeCallbacks(timeout);
        postDelayed(timeout, 15000);
        if (listener != null) listener.onRefresh();
    }

    public void stopRefreshing() {
        removeCallbacks(timeout);
        if (!refreshing) return;
        refreshing = false;
        spinner.setSpinning(false);
        hide();
    }

    private void hide() {
        pull = 0;
        spinner.animate().cancel();
        spinner.animate().translationY(-size).alpha(0f).setDuration(200)
                .withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        spinner.setVisibility(INVISIBLE);
                        spinner.setAlpha(1f);
                        spinner.setProgress(0f);
                    }
                }).start();
    }

    private static int themeColor(Context c, int attr, int fallback) {
        TypedValue tv = new TypedValue();
        return c.getTheme().resolveAttribute(attr, tv, true) ? tv.data : fallback;
    }

    private static class SpinnerView extends View {
        private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private final float pad;
        private float progress;
        private float rotation;
        private boolean spinning;
        private ValueAnimator anim;

        SpinnerView(Context c, float d) {
            super(c);
            pad = 11 * d;
            arc.setStyle(Paint.Style.STROKE);
            arc.setStrokeWidth(3.5f * d);
            arc.setStrokeCap(Paint.Cap.ROUND);
            arc.setColor(themeColor(c, com.google.android.material.R.attr.colorPrimary, 0xFF6750A4));
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.OVAL);
            bg.setColor(themeColor(c, com.google.android.material.R.attr.colorSurface, 0xFFFFFFFF));
            setBackground(bg);
            setElevation(6 * d);
        }

        void setProgress(float p) {
            progress = p;
            invalidate();
        }

        void setPullRotation(float r) {
            if (!spinning) {
                rotation = r;
                invalidate();
            }
        }

        void setSpinning(boolean s) {
            spinning = s;
            if (anim != null) {
                anim.cancel();
                anim = null;
            }
            if (s) {
                anim = ValueAnimator.ofFloat(0f, 360f);
                anim.setDuration(900);
                anim.setRepeatCount(ValueAnimator.INFINITE);
                anim.setInterpolator(new LinearInterpolator());
                anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                    @Override
                    public void onAnimationUpdate(ValueAnimator a) {
                        rotation = (float) a.getAnimatedValue();
                        invalidate();
                    }
                });
                anim.start();
            }
            invalidate();
        }

        @Override
        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            if (anim != null) anim.cancel();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            rect.set(pad, pad, getWidth() - pad, getHeight() - pad);
            float sweep = spinning ? 270f : 300f * progress;
            if (sweep <= 0f) return;
            canvas.drawArc(rect, -90f + rotation, sweep, false, arc);
        }
    }
}
