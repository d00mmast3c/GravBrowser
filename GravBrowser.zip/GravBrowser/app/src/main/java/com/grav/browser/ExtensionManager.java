package com.grav.browser;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Gerencia extensões instaladas no próprio app Grav Browser.
 * Suporta extensões no formato Chrome (CRX) e Firefox (XPI), lendo
 * manifest.json e injetando content_scripts (js/css) nas páginas que casam com "matches".
 */
public class ExtensionManager {

    public static class Block {
        final List<Pattern> matches = new ArrayList<>();
        final List<String> js = new ArrayList<>();
        final List<String> css = new ArrayList<>();

        boolean matchesUrl(String url) {
            for (Pattern p : matches) {
                if (p.matcher(url).matches()) return true;
            }
            return false;
        }
    }

    public static class Ext {
        public String dirId;
        public String name;
        public String version = "";
        public String dir;
        public boolean enabled = true;
        public final List<Block> blocks = new ArrayList<>();
    }

    public static class StoreInfo {
        public String id;
        public String downloadUrl;
    }

    public interface Done {
        void run(Ext e, String err);
    }

    private final File root;
    private final SharedPreferences prefs;
    private final List<Ext> exts = new CopyOnWriteArrayList<>();

    public ExtensionManager(Context c) {
        root = new File(c.getFilesDir(), "extensions");
        root.mkdirs();
        prefs = c.getSharedPreferences("grav_ext", Context.MODE_PRIVATE);
        File[] dirs = root.listFiles();
        if (dirs != null) {
            for (File d : dirs) {
                Ext e = parse(d);
                if (e != null) exts.add(e);
            }
        }
    }

    public List<Ext> all() {
        return new ArrayList<>(exts);
    }

    public void setEnabled(Ext e, boolean v) {
        e.enabled = v;
        prefs.edit().putBoolean(e.dirId, v).apply();
    }

    public void remove(Ext e) {
        deleteRec(new File(e.dir));
        exts.remove(e);
        prefs.edit().remove(e.dirId).apply();
    }

    public String buildInjection(String url) {
        StringBuilder sb = new StringBuilder();
        for (Ext e : exts) {
            if (!e.enabled) continue;
            for (Block b : e.blocks) {
                if (!b.matchesUrl(url)) continue;
                for (String css : b.css) {
                    sb.append("(function(){var s=document.createElement('style');s.textContent=")
                      .append(JSONObject.quote(css))
                      .append(";(document.head||document.documentElement).appendChild(s);})();\n");
                }
                for (String js : b.js) {
                    sb.append("(function(){try{\n").append(js)
                      .append("\n}catch(err){console.error('[Grav ")
                      .append(e.name.replace("'", ""))
                      .append("]',err);}})();\n");
                }
            }
        }
        return sb.toString();
    }

    public void install(final StoreInfo si, final String displayName, final Done cb) {
        new Thread(() -> {
            try {
                byte[] zip = stripCrx(download(si.downloadUrl));
                File dir = new File(root, si.id);
                deleteRec(dir);
                dir.mkdirs();
                unzip(zip, dir);
                Ext e = parse(dir);
                if (e == null) throw new IOException("manifest.json inválido");
                if (e.name == null || e.name.startsWith("__MSG_")) e.name = displayName;
                prefs.edit().putBoolean(e.dirId, true).apply();
                exts.removeIf(x -> x.dirId.equals(e.dirId));
                exts.add(e);
                cb.run(e, null);
            } catch (Exception ex) {
                cb.run(null, String.valueOf(ex.getMessage()));
            }
        }).start();
    }

    public static boolean isStoreHost(String url) {
        if (url == null) return false;
        String h = Uri.parse(url).getHost();
        return h != null && (h.endsWith("chromewebstore.google.com")
                || h.endsWith("chrome.google.com")
                || h.endsWith("addons.mozilla.org"));
    }

    public static StoreInfo parseStore(String url) {
        Uri u = Uri.parse(url);
        String host = u.getHost();
        if (host == null) return null;
        List<String> seg = u.getPathSegments();
        if (seg == null || seg.isEmpty()) return null;

        StoreInfo si = new StoreInfo();
        if (host.endsWith("chromewebstore.google.com") || host.endsWith("chrome.google.com")) {
            String last = seg.get(seg.size() - 1);
            if (!last.matches("[a-p]{32}")) return null;
            si.id = "cws_" + last;
            si.downloadUrl = "https://clients2.google.com/service/update2/crx?response=redirect"
                    + "&prodversion=131.0&acceptformat=crx2,crx3&x=id%3D" + last + "%26uc";
            return si;
        }
        if (host.endsWith("addons.mozilla.org")) {
            int i = seg.indexOf("addon");
            if (i < 0 || i + 1 >= seg.size()) return null;
            String slug = seg.get(i + 1);
            si.id = "amo_" + slug.replaceAll("[^a-zA-Z0-9_-]", "_");
            si.downloadUrl = "https://addons.mozilla.org/firefox/downloads/latest/" + slug + "/latest.xpi";
            return si;
        }
        return null;
    }

    // ---------- internos ----------

    private Ext parse(File d) {
        try {
            File mf = new File(d, "manifest.json");
            if (!mf.isFile()) return null;
            JSONObject m = new JSONObject(readText(mf));

            Ext e = new Ext();
            e.dirId = d.getName();
            e.dir = d.getAbsolutePath();
            e.name = m.optString("name", e.dirId);
            e.version = m.optString("version", "");
            e.enabled = prefs.getBoolean(e.dirId, true);

            JSONArray cs = m.optJSONArray("content_scripts");
            if (cs != null) {
                for (int i = 0; i < cs.length(); i++) {
                    JSONObject c = cs.getJSONObject(i);
                    Block b = new Block();
                    JSONArray ms = c.optJSONArray("matches");
                    if (ms != null) {
                        for (int j = 0; j < ms.length(); j++) {
                            Pattern p = toRegex(ms.optString(j));
                            if (p != null) b.matches.add(p);
                        }
                    }
                    JSONArray js = c.optJSONArray("js");
                    if (js != null) {
                        for (int j = 0; j < js.length(); j++) b.js.add(readFileOr(d, js.optString(j)));
                    }
                    JSONArray css = c.optJSONArray("css");
                    if (css != null) {
                        for (int j = 0; j < css.length(); j++) b.css.add(readFileOr(d, css.optString(j)));
                    }
                    e.blocks.add(b);
                }
            }
            return e;
        } catch (Exception ex) {
            return null;
        }
    }

    static Pattern toRegex(String m) {
        if (m == null || m.isEmpty()) return null;
        if (m.equals("<all_urls>")) return Pattern.compile(".*");
        int i = m.indexOf("://");
        if (i < 0) return null;
        String scheme = m.substring(0, i);
        String rest = m.substring(i + 3);
        String s = scheme.equals("*") ? "https?" : glob(scheme);
        String host = rest.startsWith("*.")
                ? "(?:.*\\.)?" + glob(rest.substring(2))
                : glob(rest);
        return Pattern.compile("^" + s + "://" + host + "$");
    }

    private static String glob(String g) {
        StringBuilder b = new StringBuilder();
        for (char c : g.toCharArray()) {
            if (c == '*') b.append(".*");
            else if ("\\.[]{}()+?^$|".indexOf(c) >= 0) b.append('\\').append(c);
            else b.append(c);
        }
        return b.toString();
    }

    private static String readFileOr(File d, String rel) throws IOException {
        File f = new File(d, rel);
        return f.isFile() ? readText(f) : "";
    }

    private static String readText(File f) throws IOException {
        try (InputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) bo.write(buf, 0, n);
            return new String(bo.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    private static byte[] download(String u) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        try {
            c.setInstanceFollowRedirects(true);
            c.setConnectTimeout(20000);
            c.setReadTimeout(60000);
            c.setRequestProperty("User-Agent",
                    "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36");
            int code = c.getResponseCode();
            if (code != 200) throw new IOException("Download falhou (HTTP " + code + ")");
            try (InputStream in = c.getInputStream()) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) != -1) bo.write(buf, 0, n);
                return bo.toByteArray();
            }
        } finally {
            c.disconnect();
        }
    }

    /** Remove o cabeçalho CRX (v2 ou v3), deixando o ZIP puro. */
    private static byte[] stripCrx(byte[] b) {
        if (b.length < 12 || b[0] != 'C' || b[1] != 'r' || b[2] != '2' || b[3] != '4') return b;
        int ver = le(b, 4);
        int start = ver == 2 ? 16 + le(b, 8) + le(b, 12) : 12 + le(b, 8);
        return Arrays.copyOfRange(b, start, b.length);
    }

    private static int le(byte[] b, int o) {
        return (b[o] & 0xff) | ((b[o + 1] & 0xff) << 8) | ((b[o + 2] & 0xff) << 16) | ((b[o + 3] & 0xff) << 24);
    }

    private static void unzip(byte[] zip, File dir) throws IOException {
        String base = dir.getCanonicalPath() + File.separator;
        try (ZipInputStream zin = new ZipInputStream(new ByteArrayInputStream(zip))) {
            ZipEntry ze;
            while ((ze = zin.getNextEntry()) != null) {
                File f = new File(dir, ze.getName());
                if (!f.getCanonicalPath().startsWith(base)) throw new IOException("Caminho inválido no pacote");
                if (ze.isDirectory()) {
                    f.mkdirs();
                    continue;
                }
                f.getParentFile().mkdirs();
                try (OutputStream o = new FileOutputStream(f)) {
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = zin.read(buf)) != -1) o.write(buf, 0, n);
                }
            }
        }
    }

    private static void deleteRec(File f) {
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) deleteRec(k);
        }
        f.delete();
    }
}
