package com.grav.browser;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class HistoryManager {

    public static class Entry {
        public String url;
        public String title;
        public String icon;
        public long time;

        public Bitmap bitmap() {
            if (icon == null) return null;
            byte[] d = Base64.decode(icon, Base64.DEFAULT);
            return BitmapFactory.decodeByteArray(d, 0, d.length);
        }
    }

    private static final int MAX = 1000;
    private final File file;
    private final List<Entry> items = new ArrayList<>();

    public HistoryManager(Context c) {
        file = new File(c.getFilesDir(), "history.json");
        load();
    }

    public synchronized List<Entry> list() {
        return new ArrayList<>(items);
    }

    public synchronized void add(String url, String title, Bitmap icon) {
        if (url == null || url.startsWith("about:")) return;
        Entry e = new Entry();
        e.url = url;
        e.title = (title == null || title.isEmpty()) ? url : title;
        e.time = System.currentTimeMillis();
        e.icon = encode(icon);
        for (Iterator<Entry> it = items.iterator(); it.hasNext(); ) {
            Entry o = it.next();
            if (o.url.equals(url)) {
                if (e.icon == null) e.icon = o.icon;
                it.remove();
            }
        }
        items.add(0, e);
        while (items.size() > MAX) items.remove(items.size() - 1);
        save();
    }

    public synchronized void remove(Entry e) {
        items.remove(e);
        save();
    }

    public synchronized void clear() {
        items.clear();
        save();
    }

    private static String encode(Bitmap b) {
        if (b == null) return null;
        Bitmap s = Bitmap.createScaledBitmap(b, 32, 32, true);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        s.compress(Bitmap.CompressFormat.PNG, 100, bo);
        return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
    }

    private void load() {
        if (!file.isFile()) return;
        try {
            JSONArray arr = new JSONArray(readAll(file));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Entry e = new Entry();
                e.url = o.optString("url");
                e.title = o.optString("title");
                e.icon = (o.has("icon") && !o.isNull("icon")) ? o.getString("icon") : null;
                e.time = o.optLong("time");
                items.add(e);
            }
        } catch (Exception ignored) {
        }
    }

    private void save() {
        try {
            JSONArray arr = new JSONArray();
            for (Entry e : items) {
                JSONObject o = new JSONObject();
                o.put("url", e.url);
                o.put("title", e.title);
                if (e.icon != null) o.put("icon", e.icon);
                o.put("time", e.time);
                arr.put(o);
            }
            try (OutputStream out = new FileOutputStream(file)) {
                out.write(arr.toString().getBytes(StandardCharsets.UTF_8));
            }
        } catch (Exception ignored) {
        }
    }

    private static String readAll(File f) throws Exception {
        try (InputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) bo.write(buf, 0, n);
            return new String(bo.toByteArray(), StandardCharsets.UTF_8);
        }
    }
}
