package com.grav.browser;

import android.app.Application;
import com.google.android.material.color.DynamicColors;

public class GravApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        Prefs.applyTheme(this);
        // Android 12+: cores do app seguem o estilo de cor do sistema (Material You)
        DynamicColors.applyToActivitiesIfAvailable(this);
    }
}
