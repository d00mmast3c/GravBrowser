package com.grav.browser;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatDelegate;

public class Prefs {
    private static final String FILE = "grav_prefs";

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public static boolean js(Context c) { return p(c).getBoolean("js", true); }
    public static boolean images(Context c) { return p(c).getBoolean("images", true); }
    public static boolean desktopDefault(Context c) { return p(c).getBoolean("desktop", false); }
    public static String theme(Context c) { return p(c).getString("theme", "system"); }

    public static void applyTheme(Context c) {
        int mode = AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM;
        String t = theme(c);
        if (t.equals("light")) mode = AppCompatDelegate.MODE_NIGHT_NO;
        else if (t.equals("dark")) mode = AppCompatDelegate.MODE_NIGHT_YES;
        AppCompatDelegate.setDefaultNightMode(mode);
    }

    public static String engine(Context c) { return p(c).getString("engine", "google"); }

    public static void putBool(Context c, String k, boolean v) { p(c).edit().putBoolean(k, v).apply(); }
    public static void putStr(Context c, String k, String v) { p(c).edit().putString(k, v).apply(); }

    public static String searchUrl(Context c) {
        switch (engine(c)) {
            case "ddg":  return "https://duckduckgo.com/?q=";
            case "bing": return "https://www.bing.com/search?q=";
            default:     return "https://www.google.com/search?q=";
        }
    }
}
