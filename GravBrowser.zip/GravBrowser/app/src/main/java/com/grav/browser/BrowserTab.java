package com.grav.browser;

import android.graphics.Bitmap;
import android.webkit.WebView;

public class BrowserTab {
    public final WebView web;
    public final boolean incognito;
    public String title = "";
    public String url = "";
    public Bitmap favicon;
    public boolean desktop;
    public int progress = 100;

    public BrowserTab(WebView web, boolean incognito) {
        this.web = web;
        this.incognito = incognito;
    }
}
