package com.grav.browser;

import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.WebStorage;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.CompoundButton;
import android.widget.Toast;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_settings);

        View sRoot = findViewById(R.id.settingsRoot);
        ViewCompat.setOnApplyWindowInsetsListener(sRoot, (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setTitle(R.string.settings_title);

        RadioGroup rt = findViewById(R.id.radioTheme);
        String th = Prefs.theme(this);
        if (th.equals("light")) rt.check(R.id.rbThemeLight);
        else if (th.equals("dark")) rt.check(R.id.rbThemeDark);
        else rt.check(R.id.rbThemeSystem);
        rt.setOnCheckedChangeListener((g, id) -> {
            String v = id == R.id.rbThemeLight ? "light" : id == R.id.rbThemeDark ? "dark" : "system";
            if (v.equals(Prefs.theme(this))) return;
            Prefs.putStr(this, "theme", v);
            Prefs.applyTheme(this);
        });

        CompoundButton js = findViewById(R.id.switchJs);
        js.setChecked(Prefs.js(this));
        js.setOnCheckedChangeListener((b, c) -> Prefs.putBool(this, "js", c));

        CompoundButton img = findViewById(R.id.switchImages);
        img.setChecked(Prefs.images(this));
        img.setOnCheckedChangeListener((b, c) -> Prefs.putBool(this, "images", c));

        CompoundButton desk = findViewById(R.id.switchDesktop);
        desk.setChecked(Prefs.desktopDefault(this));
        desk.setOnCheckedChangeListener((b, c) -> Prefs.putBool(this, "desktop", c));

        RadioGroup rg = findViewById(R.id.radioSearch);
        String eng = Prefs.engine(this);
        if (eng.equals("ddg")) rg.check(R.id.rbDdg);
        else if (eng.equals("bing")) rg.check(R.id.rbBing);
        else rg.check(R.id.rbGoogle);
        rg.setOnCheckedChangeListener((g, id) -> {
            String v = id == R.id.rbDdg ? "ddg" : id == R.id.rbBing ? "bing" : "google";
            Prefs.putStr(this, "engine", v);
        });

        Button clearHistory = findViewById(R.id.btnClearHistory);
        clearHistory.setOnClickListener(v -> {
            new HistoryManager(this).clear();
            Toast.makeText(this, R.string.cleared, Toast.LENGTH_SHORT).show();
        });

        Button clearData = findViewById(R.id.btnClearData);
        clearData.setOnClickListener(v -> {
            CookieManager.getInstance().removeAllCookies(null);
            CookieManager.getInstance().flush();
            WebStorage.getInstance().deleteAllData();
            Toast.makeText(this, R.string.cleared, Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
