package com.grav.browser;

import android.app.AlertDialog;
import android.content.Context;
import android.content.res.Configuration;

/**
 * AlertDialog nativo do sistema (DeviceDefault).
 * Android antigo: dialog clássico da versão. Android 12+: Material You do próprio sistema.
 * Segue o modo claro/escuro do aparelho.
 */
public class Dialogs {

    public static AlertDialog.Builder builder(Context c) {
        int mode = c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        boolean night = mode == Configuration.UI_MODE_NIGHT_YES;
        int theme = night
                ? android.R.style.Theme_DeviceDefault_Dialog_Alert
                : android.R.style.Theme_DeviceDefault_Light_Dialog_Alert;
        return new AlertDialog.Builder(c, theme);
    }
}
