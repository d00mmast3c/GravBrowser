package com.grav.browser;

import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class RowAdapter extends RecyclerView.Adapter<RowAdapter.VH> {

    public static class Row {
        public final Bitmap icon;
        public final String title;
        public final String sub;
        public final Runnable open;
        public final Runnable delete;

        public Row(Bitmap icon, String title, String sub, Runnable open, Runnable delete) {
            this.icon = icon;
            this.title = title == null ? "" : title;
            this.sub = sub == null ? "" : sub;
            this.open = open;
            this.delete = delete;
        }
    }

    private final List<Row> rows = new ArrayList<>();

    public void setRows(List<Row> r) {
        rows.clear();
        rows.addAll(r);
        notifyDataSetChanged();
    }

    @Override
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(VH h, int i) {
        Row r = rows.get(i);
        if (r.icon != null) h.icon.setImageBitmap(r.icon);
        else h.icon.setImageResource(R.drawable.ic_globe);
        h.title.setText(r.title);
        h.sub.setText(r.sub);
        h.itemView.setOnClickListener(v -> {
            if (r.open != null) r.open.run();
        });
        if (r.delete != null) {
            h.close.setVisibility(View.VISIBLE);
            h.close.setOnClickListener(v -> r.delete.run());
        } else {
            h.close.setVisibility(View.GONE);
            h.close.setOnClickListener(null);
        }
    }

    @Override
    public int getItemCount() {
        return rows.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        final ImageView icon;
        final TextView title;
        final TextView sub;
        final ImageButton close;

        VH(View v) {
            super(v);
            icon = v.findViewById(R.id.rowIcon);
            title = v.findViewById(R.id.rowTitle);
            sub = v.findViewById(R.id.rowSub);
            close = v.findViewById(R.id.rowClose);
        }
    }
}
